
/*
  Library Manager Pro v3 — Themes + Motion
  Author: Ahmed Riad Younes
  Vanilla JS + Bootstrap + localStorage
*/

(function(){
  'use strict';

  const STORAGE_KEY = 'lmp_v3_books';
  const SETTINGS_KEY = 'lmp_v3_settings';
  const ID = () => Math.random().toString(36).slice(2, 11);

  // ---------------- Settings ----------------
  const defaults = { lang:'ar', perPage: 10, theme: 'ocean' };
  const loadSettings = () => { try { return { ...defaults, ...(JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}')) }; } catch { return {...defaults}; } };
  const saveSettings = (s) => localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  let settings = loadSettings();
  document.documentElement.setAttribute('data-theme', settings.theme || 'ocean');

  // ---------------- Data ----------------
  const DEMO = [
    { title: "الخوارزميات", author: "توماس كورمن", category: "علوم الحاسوب", year: 2010, tags: ["خوارزميات"], isbn: "9780262033848", lang: "العربية", status: "available" },
    { title: "Clean Code", author: "Robert C. Martin", category: "Programming", year: 2008, tags: ["code","craft"], isbn: "9780132350884", lang: "English", status: "available" },
    { title: "Operating Systems", author: "Silberschatz", category: "علوم الحاسوب", year: 2014, tags: ["OS"], isbn: "9780133591620", lang: "English", status: "borrowed", borrower: "محمد", due: "2025-09-05" },
    { title: "Python Crash Course", author: "Eric Matthes", category: "Programming", year: 2019, tags: ["python"], isbn: "9781593279288", lang: "English", status: "available" },
    { title: "ذكاء اصطناعي مُيسر", author: "أندرو نج", category: "ذكاء اصطناعي", year: 2023, tags: ["AI"], isbn: "AI-12345", lang: "العربية", status: "available" }
  ];

  const saveList = (arr) => localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
  const loadList = () => { try { const v = JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]'); return Array.isArray(v)?v:[]; } catch { return []; } };
  const seedIfEmpty = () => { if (loadList().length === 0) { saveList(DEMO.map(b=>({ id:ID(), cover:'', notes:'', createdAt:new Date().toISOString(), ...b }))); } };

  // ---------------- Helpers ----------------
  const $ = (s,ctx=document)=>ctx.querySelector(s);
  const $$ = (s,ctx=document)=>Array.from(ctx.querySelectorAll(s));
  const escapeHtml = (s) => (s||'').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const readFileText = (file) => new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsText(file); });
  const readDataURL  = (file) => new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(file); });
  const toCSV = (arr) => {
    const headers = ['id','title','author','category','year','tags','isbn','lang','status','borrower','due','notes','createdAt'];
    const esc = (v) => {
      if (v==null) return '';
      const s = String(Array.isArray(v)?v.join('|'):v);
      return s.includes(',')||s.includes('"')||s.includes('\n') ? `"${s.replace(/"/g,'""')}"` : s;
    };
    return [headers.join(',')].concat(arr.map(o => headers.map(h => esc(o[h])).join(','))).join('\n');
  };
  const download = (filename, content, type='text/plain') => {
    const blob = new Blob([content], {type}); const url = URL.createObjectURL(blob);
    const a=document.createElement('a'); a.href=url; a.download=filename; a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 500);
  };
  const parseTags = (s)=> s? s.split(',').map(x=>x.trim()).filter(Boolean):[];
  const tagsText = (arr)=> (arr||[]).slice(0,4).map(t=>`<span class="badge bg-light text-dark border me-1">${escapeHtml(t)}</span>`).join('');

  // ---------------- State ----------------
  let state = { books:[], page:1, perPage: settings.perPage||10, filters:{ q:'', cat:'', status:'', yearMin:'', yearMax:'', sort:'-createdAt' }, selection:new Set(), lastDeleted:null };

  // ---------------- Charts & Stats ----------------
  let chartCat, chartStatus;
  const renderCharts = (byCat, statusCounts) => {
    if (!window.Chart) return;
    if (chartCat) chartCat.destroy(); if (chartStatus) chartStatus.destroy();
    chartCat = new Chart($('#chartCategories'), { type:'bar', data:{ labels:Object.keys(byCat), datasets:[{label:'حسب التصنيف', data:Object.values(byCat)}] }, options:{ responsive:true, plugins:{legend:{display:false}} } });
    chartStatus = new Chart($('#chartStatus'), { type:'doughnut', data:{ labels:['متوفر','مستعار'], datasets:[{ data:[statusCounts.available, statusCounts.borrowed] }] }, options:{ responsive:true } });
  };
  const refreshStats = () => {
    const total = state.books.length;
    const available = state.books.filter(b=>b.status==='available').length;
    const borrowed = total - available;
    const tags = new Set(); state.books.forEach(b => (b.tags||[]).forEach(t=>tags.add(t)));
    $('#stat-total').textContent = total;
    $('#stat-available').textContent = available;
    $('#stat-borrowed').textContent = borrowed;
    $('#stat-tags').textContent = tags.size;
    // Hero mini stats
    $('#stat-total-hero').textContent = total;
    $('#stat-available-hero').textContent = available;
    $('#stat-borrowed-hero').textContent = borrowed;
    const pct = total>0 ? Math.round((available/total)*100) : 0;
    $('#hero-progress').style.width = pct + '%';

    const byCat = {}; state.books.forEach(b=>{ const k=b.category||'—'; byCat[k]=(byCat[k]||0)+1; });
    const tb = $('#tbl-cat'); tb.innerHTML='';
    Object.entries(byCat).sort((a,b)=>b[1]-a[1]).forEach(([c,n])=>{ const tr=document.createElement('tr'); tr.innerHTML=`<td>${escapeHtml(c)}</td><td>${n}</td>`; tb.appendChild(tr); });

    if (window.Chart) { $('#chartCategoriesFallback').classList.add('d-none'); $('#chartStatusFallback').classList.add('d-none'); renderCharts(byCat, {available, borrowed}); }
    else { $('#chartCategoriesFallback').classList.remove('d-none'); $('#chartStatusFallback').classList.remove('d-none'); }
  };

  // ---------------- Filters & Table ----------------
  const fillFilters = () => {
    const sel = $('#filter-category');
    const cats = Array.from(new Set(loadList().map(b=>b.category).filter(Boolean))).sort();
    sel.innerHTML = `<option value="">كل التصنيفات</option>` + cats.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    $('#per-page').value = state.perPage;
  };

  const applyFilters = () => {
    let arr = loadList();
    const f = state.filters; const q = f.q.toLowerCase().trim();
    if (q) arr = arr.filter(b => [b.title,b.author,b.category,b.isbn,b.lang,(b.tags||[]).join(' ')].some(v => (v||'').toLowerCase().includes(q)));
    if (f.cat) arr = arr.filter(b => (b.category||'')===f.cat);
    if (f.status) arr = arr.filter(b => b.status===f.status);
    if (f.yearMin) arr = arr.filter(b => (+b.year||0) >= (+f.yearMin));
    if (f.yearMax) arr = arr.filter(b => (+b.year||0) <= (+f.yearMax));

    const sort = f.sort; const key = sort.replace('-','');
    arr.sort((a,b)=>{
      let va=a[key], vb=b[key];
      if (key==='year') { va=+va||0; vb=+vb||0; }
      else { va=(va??'').toString().toLowerCase(); vb=(vb??'').toString().toLowerCase(); }
      const r = va>vb?1:va<vb?-1:0; return sort.startsWith('-')? -r:r;
    });

    state.books = arr;
    refreshStats();
    renderTable();
    fillFilters();
  };

  const renderTable = () => {
    const start = (state.page-1)*state.perPage;
    const rows = $('#rows'); rows.innerHTML='';
    const pageItems = state.books.slice(start, start+state.perPage);
    pageItems.forEach(b=>{
      const tr=document.createElement('tr');
      tr.innerHTML = `
        <td><input type="checkbox" data-check="${b.id}"/></td>
        <td>${b.cover ? `<img src="${b.cover}" class="cover-thumb" alt="">` : `<img src="assets/img/placeholder.png" class="cover-thumb" alt="">`}</td>
        <td class="fw-semibold">${escapeHtml(b.title||'—')}</td>
        <td>${escapeHtml(b.author||'—')}</td>
        <td>${escapeHtml(b.category||'—')}</td>
        <td>${b.year||'—'}</td>
        <td>${tagsText(b.tags)}</td>
        <td>${b.status==='available'?`<span class="badge badge-status badge-available">متوفر</span>`:`<span class="badge badge-status badge-borrowed">مستعار</span>`}</td>
        <td>
          <div class="d-flex gap-1">
            <button class="btn btn-primary btn-sm" data-act="edit" data-id="${b.id}" title="تعديل">✏️</button>
            <button class="btn btn-danger btn-sm" data-act="del" data-id="${b.id}" title="حذف">🗑️</button>
            ${b.status==='available'
              ? `<button class="btn btn-warning btn-sm" data-act="borrow" data-id="${b.id}" title="استعارة">📥</button>`
              : `<button class="btn btn-success btn-sm" data-act="return" data-id="${b.id}" title="إرجاع">↩️</button>`}
          </div>
        </td>`;
      rows.appendChild(tr);
    });

    const total = state.books.length;
    const from = total===0?0:start+1;
    const to = Math.min(start+state.perPage, total);
    $('#table-meta').textContent = `عرض ${from}-${to} من ${total}`;
  };

  // ---------------- CRUD ----------------
  const openModal = (editing=false, book=null) => {
    $('.modal-title').textContent = editing ? 'تعديل كتاب' : 'إضافة كتاب';
    $('#book-id').value = editing ? book.id : '';
    $('#book-title').value = editing ? (book.title||'') : '';
    $('#book-author').value = editing ? (book.author||'') : '';
    $('#book-category').value = editing ? (book.category||'') : '';
    $('#book-year').value = editing ? (book.year||'') : '';
    $('#book-isbn').value = editing ? (book.isbn||'') : '';
    $('#book-lang').value = editing ? (book.lang||'') : '';
    $('#book-tags').value = editing ? (book.tags||[]).join(', ') : '';
    $('#book-notes').value = editing ? (book.notes||'') : '';
    $('#cover-preview').src = editing && book.cover ? book.cover : 'assets/img/placeholder.png';
    bootstrap.Modal.getOrCreateInstance('#bookModal').show();
  };

  const submitForm = async (e) => {
    e.preventDefault();
    const id = $('#book-id').value || ID();
    const title = $('#book-title').value.trim();
    const author = $('#book-author').value.trim();
    if (!title || !author) { alert('الاسم والمؤلف مطلوبان'); return; }
    const category = $('#book-category').value.trim();
    const year = parseInt($('#book-year').value) || '';
    const isbn = $('#book-isbn').value.trim();
    const lang = $('#book-lang').value.trim();
    const tags = ($('#book-tags').value||'').split(',').map(x=>x.trim()).filter(Boolean);
    const notes = $('#book-notes').value.trim();
    const books = loadList();
    let coverData = '';
    const file = $('#book-cover').files[0];
    if (file) coverData = await readDataURL(file);

    const existing = books.find(b=>b.id===id);
    if (existing) {
      Object.assign(existing, { title, author, category, year, isbn, lang, tags, notes });
      if (coverData) existing.cover = coverData;
    } else {
      books.unshift({ id, title, author, category, year, isbn, lang, tags, notes, cover: coverData, status:'available', createdAt: new Date().toISOString() });
    }
    saveList(books);
    bootstrap.Modal.getInstance('#bookModal').hide();
    applyFilters();
  };

  const delBook = (id) => {
    const books = loadList(); const idx = books.findIndex(b=>b.id===id);
    if (idx>=0) {
      const backup = books[idx]; books.splice(idx,1); saveList(books);
      applyFilters();
      if (confirm('تم الحذف. هل تريد التراجع؟')) { const cur=loadList(); cur.unshift(backup); saveList(cur); applyFilters(); }
    }
  };
  const borrowBook = (id, name, due) => {
    const books = loadList(); const b=books.find(x=>x.id===id);
    if (b) { b.status='borrowed'; b.borrower=name||prompt('اسم المستعير')||''; b.due=due||prompt('تاريخ الإرجاع (YYYY-MM-DD)')||''; }
    saveList(books); applyFilters();
  };
  const returnBook = (id) => {
    const books = loadList(); const b=books.find(x=>x.id===id);
    if (b) { b.status='available'; b.borrower=''; b.due=''; }
    saveList(books); applyFilters();
  };

  // ---------------- Export/Import/Print ----------------
  const exportCSV = () => download('library_books.csv', toCSV(loadList()), 'text/csv');
  const exportJSON = () => download('library_books.json', JSON.stringify(loadList(), null, 2), 'application/json');
  const importData = async (file) => {
    const name = (file.name||'').toLowerCase();
    if (name.endsWith('.csv')) {
      const text = await readFileText(file);
      const [headerLine, ...lines] = text.split(/\r?\n/).filter(Boolean);
      const headers = headerLine.split(',').map(h=>h.trim());
      const rows = lines.map(line => { const parts=line.split(','); const obj={}; headers.forEach((h,i)=>obj[h]=parts[i]); return obj; });
      const items = rows.map(o => ({
        id: o.id || ID(),
        title: o.title || '',
        author: o.author || '',
        category: o.category || '',
        year: o.year ? +o.year : '',
        tags: o.tags ? o.tags.split('|').map(x=>x.trim()).filter(Boolean) : [],
        isbn: o.isbn || '', lang: o.lang || '',
        status: o.status==='borrowed'?'borrowed':'available',
        borrower: o.borrower||'', due: o.due||'',
        notes: o.notes||'', cover:'', createdAt: o.createdAt || new Date().toISOString()
      }));
      saveList(items); applyFilters();
    } else {
      const json = JSON.parse(await readFileText(file));
      if (!Array.isArray(json)) throw new Error('Invalid JSON');
      const items = json.map(o => ({
        id: o.id || ID(),
        title: o.title || '', author: o.author || '',
        category: o.category || '', year: o.year||'',
        tags: Array.isArray(o.tags)?o.tags:(o.tags||'').split(',').map(x=>x.trim()).filter(Boolean),
        isbn: o.isbn||'', lang: o.lang||'',
        status: o.status==='borrowed'?'borrowed':'available',
        borrower: o.borrower||'', due: o.due||'',
        notes: o.notes||'', cover: o.cover||'',
        createdAt: o.createdAt || new Date().toISOString()
      }));
      saveList(items); applyFilters();
    }
  };
  const printReport = () => {
    const win = window.open('', '_blank');
    const rows = state.books.map(b => `
      <tr>
        <td>${escapeHtml(b.title)}</td>
        <td>${escapeHtml(b.author)}</td>
        <td>${escapeHtml(b.category||'—')}</td>
        <td>${b.year||'—'}</td>
        <td>${(b.tags||[]).join(', ')}</td>
        <td>${b.status==='available'?'متوفر':'مستعار'}</td>
      </tr>`).join('');
    win.document.write(`
      <html><head><meta charset="utf-8"><title>تقرير الكتب</title>
      <style>body{font-family:system-ui,Segoe UI,Arial; padding:20px}
      table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px}th{background:#f7f7f7}</style>
      </head><body>
      <h3>تقرير الكتب (${state.books.length})</h3>
      <table><thead><tr><th>العنوان</th><th>المؤلف</th><th>التصنيف</th><th>السنة</th><th>وسوم</th><th>الحالة</th></tr></thead>
      <tbody>${rows}</tbody></table>
      <script>window.onload=()=>window.print()</script>
      </body></html>`);
    win.document.close();
  };

  // ---------------- Motion (AOS-like) ----------------
  const observer = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if (e.isIntersecting) {
        e.target.classList.add('in');
        observer.unobserve(e.target);
      }
    });
  }, { rootMargin:'0px 0px -10% 0px', threshold: .15 });

  const bindReveals = () => $$('.reveal').forEach(el => observer.observe(el));

  // Scroll progress + to-top
  const progress = $('#progress span');
  const toTop = $('#to-top');
  const onScroll = () => {
    const h = document.documentElement;
    const scrolled = (h.scrollTop) / (h.scrollHeight - h.clientHeight);
    progress.style.width = (scrolled*100).toFixed(2) + '%';
    if (h.scrollTop > 300) toTop.classList.add('show'); else toTop.classList.remove('show');
  };

  // ---------------- Boot ----------------
  window.addEventListener('DOMContentLoaded', () => {
    seedIfEmpty();

    // Theme select
    const themeSel = $('#theme-select');
    themeSel.value = settings.theme || 'ocean';
    themeSel.addEventListener('change', () => {
      const v = themeSel.value; settings.theme = v; saveSettings(settings);
      document.documentElement.setAttribute('data-theme', v);
    });

    // Language toggle (ar/en UI texts minimal — core app بالعربي)
    $('#btn-lang').addEventListener('click', () => {
      settings.lang = settings.lang==='ar' ? 'en' : 'ar';
      saveSettings(settings);
      document.documentElement.lang = settings.lang==='ar'?'ar':'en';
      document.documentElement.dir  = settings.lang==='ar'?'rtl':'ltr';
      $('#btn-lang').textContent = settings.lang==='ar' ? 'EN' : 'AR';
      applyFilters();
    });
    $('#btn-lang').textContent = settings.lang==='ar' ? 'EN' : 'AR';

    // Handlers
    $('#btn-add').addEventListener('click', ()=>openModal(false));
    $('#bookForm').addEventListener('submit', submitForm);
    $('#book-cover').addEventListener('change', async (e)=>{
      const f = e.target.files[0]; if (!f) return;
      $('#cover-preview').src = await readDataURL(f);
    });

    $('#search').addEventListener('input', e=>{ state.filters.q=e.target.value; state.page=1; applyFilters(); });
    $('#year-min').addEventListener('input', e=>{ state.filters.yearMin=e.target.value; state.page=1; applyFilters(); });
    $('#year-max').addEventListener('input', e=>{ state.filters.yearMax=e.target.value; state.page=1; applyFilters(); });
    $('#filter-category').addEventListener('change', e=>{ state.filters.cat=e.target.value; state.page=1; applyFilters(); });
    $('#filter-status').addEventListener('change', e=>{ state.filters.status=e.target.value; state.page=1; applyFilters(); });
    $('#sort-by').addEventListener('change', e=>{ state.filters.sort=e.target.value; state.page=1; applyFilters(); });
    $('#per-page').addEventListener('change', e=>{
      const v = Math.max(5, Math.min(50, parseInt(e.target.value)||10));
      state.perPage = v; settings.perPage=v; saveSettings(settings); state.page=1; applyFilters();
    });

    $('#prev').addEventListener('click', ()=>{ if (state.page>1){ state.page--; renderTable(); } });
    $('#next').addEventListener('click', ()=>{ if (state.page*state.perPage < state.books.length){ state.page++; renderTable(); } });

    $('#btn-export-csv').addEventListener('click', exportCSV);
    $('#btn-export-json').addEventListener('click', exportJSON);
    $('#import-file').addEventListener('change', (e)=>{ const f=e.target.files[0]; if(f) importData(f).catch(()=>alert('خطأ في الاستيراد')); e.target.value=''; });
    $('#btn-print').addEventListener('click', printReport);

    $('#check-all').addEventListener('change', (e)=>{
      const ids = $$('#rows input[type="checkbox"]').map(cb => cb.getAttribute('data-check'));
      if (e.target.checked) ids.forEach(id=>state.selection.add(id)); else state.selection.clear();
      $$('#rows input[type="checkbox"]').forEach(cb => cb.checked = e.target.checked);
    });
    $('#rows').addEventListener('change', (e)=>{
      if (e.target.matches('input[type="checkbox"][data-check]')) {
        const id = e.target.getAttribute('data-check');
        if (e.target.checked) state.selection.add(id); else state.selection.delete(id);
      }
    });
    $('#rows').addEventListener('click', (e)=>{
      const btn = e.target.closest('button[data-act]'); if (!btn) return;
      const id = btn.getAttribute('data-id'); const act = btn.getAttribute('data-act');
      if (act==='edit') { const b=loadList().find(x=>x.id===id); if (b) openModal(true,b); }
      else if (act==='del') delBook(id);
      else if (act==='borrow') borrowBook(id);
      else if (act==='return') returnBook(id);
    });

    // Motion + scroll UI
    bindReveals();
    document.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    $('#to-top').addEventListener('click', ()=>window.scrollTo({top:0, behavior:'smooth'}));

    // Initial render
    applyFilters();
  });
})();
